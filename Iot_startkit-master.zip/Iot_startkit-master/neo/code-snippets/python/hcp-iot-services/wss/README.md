These code snippets show primitives for interacting with the SAP Cloud Platform Internet of Things
via wss (WebSockets).

To run these scripts you need a Python 2.x installation with the modules
autobahn and twisted installed. autobahn is available at
http://autobahn.ws/python/ and twisted is available at
https://pypi.python.org/pypi/Twisted or via the respective package manager of
your system.
