These code snippets show primitives for interacting with the SAP Cloud Platform Internet of Things
via https.

To run these scripts you need a Python 2.x installation with the urllib3 module
installed. urllib3 is available at https://pypi.python.org/pypi/urllib3
