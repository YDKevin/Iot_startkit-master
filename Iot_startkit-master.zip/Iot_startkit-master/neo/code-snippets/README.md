This directory holds specific "code snippets" that can be integrated into
programs with working end-to-end functionality.
