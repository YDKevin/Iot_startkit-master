package com.sap.iot.starterkit.mqtt.ingest.type;

public interface Authorization {

}
