Please refer to the 
[step by step installation guide](../../../hardware/raspberry-pi/README.md) 
for usage of the example code with a Raspberry Pi and peripherals attached 
via a GrovePi shield. 
