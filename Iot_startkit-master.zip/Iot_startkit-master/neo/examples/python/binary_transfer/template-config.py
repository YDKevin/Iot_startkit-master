print("Please configure appropriately and then remove this line !"); exit();

# ===== Your specific configuration goes below / please adapt ========

host='your_hcp_accout_id.hanatrial.ondemand.com'
device_id='configure in IoT Cockpit'
oauth_token='configure in IoT Cockpit'
credentials='account_username:account_password'

message_type_upstream='configure in IoT Cockpit'
message_type_downstream='configure in IoT Cockpit'

fieldname_upstream='configure in IoT Cockpit'
fieldname_downstream='configure in IoT Cockpit'

# ===== nothing to be changed / configured below this line ===========
