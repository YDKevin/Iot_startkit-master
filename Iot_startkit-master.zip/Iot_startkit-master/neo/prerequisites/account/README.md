# Getting started in the Cloud

## Get SAP Cloud Platform Developer Account

You need a free SAP Cloud Platform developer account (Trial Landscape). Please, follow the instructions described by the following link [Signing Up for a Developer Account](https://help.hana.ondemand.com/help/frameset.htm?65d74d39cb3a4bf8910cd36ec54d2b99.html)

>Next Step [Enable Internet of Things](../service)