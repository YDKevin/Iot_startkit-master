# e.g. trial.cp.iot.sap
export INSTANCE='<instance>'

# e.g. root
export USER='<user>'

# user password
export PASSWORD='<password>'

# coap | file | modbus | opcua | sigfox | snmp
export PROTOCOL='<protocol>'
