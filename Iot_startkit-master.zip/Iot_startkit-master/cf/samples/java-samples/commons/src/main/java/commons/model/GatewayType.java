package commons.model;

import com.google.gson.annotations.SerializedName;

public enum GatewayType {

	@SerializedName("cloud") CLOUD,

	@SerializedName("edge") EDGE

}
