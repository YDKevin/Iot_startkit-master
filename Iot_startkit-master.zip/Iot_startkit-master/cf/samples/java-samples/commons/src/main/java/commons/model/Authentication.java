package commons.model;

public class Authentication {

	private String secret;

	private String pem;

	private String password;

	public String getSecret() {
		return secret;
	}

	public String getPem() {
		return pem;
	}

	public String getPassword() {
		return password;
	}

}
