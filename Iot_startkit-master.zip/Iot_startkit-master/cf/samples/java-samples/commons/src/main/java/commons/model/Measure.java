package commons.model;

public class Measure {

}
