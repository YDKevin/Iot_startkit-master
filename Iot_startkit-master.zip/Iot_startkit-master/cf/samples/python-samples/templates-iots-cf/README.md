We provide examples that cover the full process of creating and using devices.
These program also generate code for the repective usage scenarios.

* [Upstream data transfer with REST](./template-upstream-rest)
* [Bi-directional data transfer with MQTT](./template-bidirect-mqtt)
