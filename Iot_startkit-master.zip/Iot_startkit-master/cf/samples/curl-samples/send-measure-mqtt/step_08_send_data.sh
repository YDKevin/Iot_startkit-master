# step_08_send_data.sh

. ./config.sh

python2.7 mqtt-ingest.py
