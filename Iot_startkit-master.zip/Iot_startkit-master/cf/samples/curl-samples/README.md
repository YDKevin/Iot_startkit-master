# curl samples for the SAP Cloud Platform Internet of Things for the Cloud Foundry Environment

* [Sending measures to the Gateway Cloud REST](./send-measure-rest)
* [Sending measures to the Gateway Cloud MQTT](./send-measure-mqtt)
